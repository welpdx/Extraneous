Clipboard contains: http://example.ca
When using Ctrl + V:   							text
When using Ctrl + Shift + V: 				text


Note:
- Hotkey is set to `Ctrl + Shift + V` instead of `Ctrl + V`

