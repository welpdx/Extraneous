---
title: test
author: &author Smith, A.
tags: 
  - *author 
---

![gif](https://i.imgur.com/gogApFd.gif)