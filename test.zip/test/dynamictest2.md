---
location: [51.02532675,10.699996]
---

<img src="https://wttr.in/51.02532675,10.699996_0tqp_lang=en.png">

```
<%+*
// This code stops running after running it the first time. I suspect that it has something to do with some kinda cache. Just reload or change this code down here.
try {
var displayString = '<' + 'img src="https://wttr.in/{0},{1}_0tqp_lang=en.png"'.format(tp.frontmatter.location[0], tp.frontmatter.location[1]) + '>' 
} catch {
new Notice("wttr.in did not give an output \nPlease run this script after a few seconds.",2000);
displayString = "Please reload"
}
let curFile = this.app.workspace.getActiveFile(); 
const curContent = await this.app.vault.read(curFile); 
var curFileLines = curContent.split('\n');

var i1 = curFileLines.indexOf("```")
var i2 = curFileLines.indexOf("<%+*")
var i3 = curFileLines.indexOf("```",(i1+1))

if (i2-i1 == 1){
curFileLines[i1-2] = []
curFileLines[i1-2] = displayString
curFileLines = curFileLines.join("\n");
await app.vault.modify(curFile, curFileLines);
} else {
console.log("Can't find block quote. Check format of the code block and of <%+*")
}
%>
```




