---
Title: 'Does slacktivism hurt activism?: The effects of moral balancing and consistency in online activism'
Citekey: lee2013
Authors: Yu-Hao Lee, Gary Hsieh
Year: 2013
Date: 2013-04-27
timesCited: 239
Tags: #zot/engl255a5/slacktivism
---

Links:
  - [Local library](zotero://select/items/1_4NBR7WHY)
  - DOI: [10.1145/2470654.2470770](https://doi.org/10.1145/2470654.2470770)
  - 
## Abstract

In this paper we explore how the decision of partaking in low-cost, low-risk online activism - slacktivism - \'14may affect subsequent civic action. Based on moral balancing and consistency effects, we designed an online experiment to test if signing or not signing an online petition increased or decreased subsequent contribution to a charity. We found that participants who signed the online petition were significantly more likely to donate money to a related charity, demonstrating a consistency effect. We also found that participants who did not sign the petition donated significantly more money to an unrelated charity, demonstrating a moral balancing effect. The results suggest that exposure to an online activism influences individual decision on subsequent civic actions.



## Notes


